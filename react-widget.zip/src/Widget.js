import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';

const Widget = (componentName ,elementQuery) => {
    const component = componentName || <App></App>;

    ReactDOM.render(
        component,
        document.querySelector(elementQuery) 
    );
  }

export default Widget;