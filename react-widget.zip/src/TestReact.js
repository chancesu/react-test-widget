import React from 'react';
import './App.css';

function TestReact() {
  return (
    <div>
        TestReact component
    </div>
  );
}

export default TestReact;
