import React from 'react';
import './index.css';
import Widget from './Widget';
import App from './App';
import TestReact from './TestReact';

Widget(<TestReact/>,'#root')
// Widget(<App/>,'#root')